import time
import os
import instaloader
from social_links import extract_social_links
from models import (
    cache_profile,
    get_cached_profile,
    cache_relationships,
    get_cached_relationships,
)

REQUEST_DELAY = 2  # seconds between requests


def _get_loader():
    loader = instaloader.Instaloader(
        download_pictures=False,
        download_videos=False,
        download_video_thumbnails=False,
        download_geotags=False,
        download_comments=False,
        save_metadata=False,
        compress_json=False,
    )
    # Login if credentials are available (needed for follower/following lists)
    ig_user = os.environ.get("IG_USERNAME")
    ig_pass = os.environ.get("IG_PASSWORD")
    if ig_user and ig_pass:
        try:
            loader.login(ig_user, ig_pass)
        except Exception as e:
            print(f"Instagram login failed: {e}")
    return loader


_loader = None


def get_loader():
    global _loader
    if _loader is None:
        _loader = _get_loader()
    return _loader


def scrape_profile(username):
    cached = get_cached_profile(username)
    if cached:
        return cached

    loader = get_loader()
    try:
        profile = instaloader.Profile.from_username(loader.context, username)
    except instaloader.exceptions.ProfileNotExistsException:
        return {"error": f"Profile '{username}' does not exist"}
    except instaloader.exceptions.ConnectionException as e:
        return {"error": f"Connection error: {e}"}
    except Exception as e:
        return {"error": f"Failed to load profile: {e}"}

    social_links = extract_social_links(profile.biography, profile.external_url)

    profile_data = {
        "username": profile.username,
        "full_name": profile.full_name,
        "bio": profile.biography,
        "external_url": profile.external_url or "",
        "followers_count": profile.followers,
        "following_count": profile.followees,
        "profile_pic_url": profile.profile_pic_url,
        "is_private": profile.is_private,
        "social_links": social_links,
    }

    cache_profile(profile_data)
    return profile_data


def scrape_followers(username, limit=50):
    cached = get_cached_relationships(username, "follower")
    if cached:
        return cached[:limit]

    loader = get_loader()
    try:
        profile = instaloader.Profile.from_username(loader.context, username)
    except Exception as e:
        return {"error": str(e)}

    if profile.is_private:
        return {"error": "Profile is private — cannot access followers"}

    followers = []
    try:
        for i, follower in enumerate(profile.get_followers()):
            if i >= limit:
                break
            followers.append(follower.username)
            time.sleep(REQUEST_DELAY)
    except instaloader.exceptions.LoginRequiredException:
        return {"error": "Login required to access followers. Set IG_USERNAME and IG_PASSWORD environment variables."}
    except Exception as e:
        return {"error": f"Failed to fetch followers: {e}"}

    cache_relationships(username, followers, "follower")
    return followers


def scrape_following(username, limit=50):
    cached = get_cached_relationships(username, "following")
    if cached:
        return cached[:limit]

    loader = get_loader()
    try:
        profile = instaloader.Profile.from_username(loader.context, username)
    except Exception as e:
        return {"error": str(e)}

    if profile.is_private:
        return {"error": "Profile is private — cannot access following list"}

    following = []
    try:
        for i, followee in enumerate(profile.get_followees()):
            if i >= limit:
                break
            following.append(followee.username)
            time.sleep(REQUEST_DELAY)
    except instaloader.exceptions.LoginRequiredException:
        return {"error": "Login required to access following. Set IG_USERNAME and IG_PASSWORD environment variables."}
    except Exception as e:
        return {"error": f"Failed to fetch following: {e}"}

    cache_relationships(username, following, "following")
    return following


def build_graph(username, depth=0, max_connections=50):
    """Build a graph data structure for the given username.

    depth=0: just the target profile + social links
    depth=1: also scrape followers/following and their profiles
    depth=2: two levels deep (slow, use small max_connections)
    """
    nodes = []
    edges = []
    visited = set()
    errors = []

    def add_profile_node(uname, level):
        if f"instagram:{uname}" in visited:
            return
        visited.add(f"instagram:{uname}")

        profile_data = scrape_profile(uname)
        if "error" in profile_data:
            errors.append({"username": uname, "error": profile_data["error"]})
            # Still add a minimal node
            nodes.append({
                "id": f"instagram:{uname}",
                "type": "instagram",
                "label": uname,
                "error": profile_data["error"],
            })
            return

        nodes.append({
            "id": f"instagram:{uname}",
            "type": "instagram",
            "label": uname,
            "full_name": profile_data.get("full_name", ""),
            "bio": profile_data.get("bio", ""),
            "pic": profile_data.get("profile_pic_url", ""),
            "followers_count": profile_data.get("followers_count", 0),
            "following_count": profile_data.get("following_count", 0),
            "is_private": profile_data.get("is_private", False),
        })

        # Add social link nodes + edges
        for link in profile_data.get("social_links", []):
            link_id = f"{link['platform']}:{link.get('username') or link['url']}"
            if link_id not in visited:
                visited.add(link_id)
                nodes.append({
                    "id": link_id,
                    "type": link["platform"],
                    "label": link.get("username") or link["label"],
                    "url": link["url"],
                    "color": link["color"],
                })
            edges.append({
                "source": f"instagram:{uname}",
                "target": link_id,
                "type": "linked_profile",
            })

        # Scrape connections if depth allows
        if level < depth:
            time.sleep(REQUEST_DELAY)

            followers = scrape_followers(uname, limit=max_connections)
            if isinstance(followers, list):
                for f_user in followers:
                    edges.append({
                        "source": f"instagram:{f_user}",
                        "target": f"instagram:{uname}",
                        "type": "follows",
                    })
                    add_profile_node(f_user, level + 1)
                    time.sleep(REQUEST_DELAY)

            following = scrape_following(uname, limit=max_connections)
            if isinstance(following, list):
                for f_user in following:
                    edges.append({
                        "source": f"instagram:{uname}",
                        "target": f"instagram:{f_user}",
                        "type": "follows",
                    })
                    add_profile_node(f_user, level + 1)
                    time.sleep(REQUEST_DELAY)

    add_profile_node(username, 0)

    return {
        "nodes": nodes,
        "edges": edges,
        "errors": errors,
        "stats": {
            "total_nodes": len(nodes),
            "total_edges": len(edges),
            "instagram_profiles": sum(1 for n in nodes if n["type"] == "instagram"),
            "social_links": sum(1 for n in nodes if n["type"] != "instagram"),
        },
    }
