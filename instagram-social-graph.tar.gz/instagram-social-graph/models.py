import sqlite3
import json
import os
from datetime import datetime, timedelta

DB_PATH = os.path.join(os.path.dirname(__file__), "cache.db")
CACHE_EXPIRY_HOURS = 24


def get_db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL")
    return conn


def init_db():
    conn = get_db()
    conn.executescript("""
        CREATE TABLE IF NOT EXISTS profiles (
            username TEXT PRIMARY KEY,
            full_name TEXT,
            bio TEXT,
            external_url TEXT,
            followers_count INTEGER,
            following_count INTEGER,
            profile_pic_url TEXT,
            is_private INTEGER DEFAULT 0,
            social_links_json TEXT,
            scraped_at TEXT
        );

        CREATE TABLE IF NOT EXISTS relationships (
            source_username TEXT,
            target_username TEXT,
            relationship_type TEXT,
            scraped_at TEXT,
            PRIMARY KEY (source_username, target_username, relationship_type)
        );
    """)
    conn.commit()
    conn.close()


def _is_expired(scraped_at_str):
    if not scraped_at_str:
        return True
    scraped_at = datetime.fromisoformat(scraped_at_str)
    return datetime.now() - scraped_at > timedelta(hours=CACHE_EXPIRY_HOURS)


def cache_profile(profile_data):
    conn = get_db()
    conn.execute(
        """INSERT OR REPLACE INTO profiles
           (username, full_name, bio, external_url, followers_count,
            following_count, profile_pic_url, is_private, social_links_json, scraped_at)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
        (
            profile_data["username"],
            profile_data.get("full_name", ""),
            profile_data.get("bio", ""),
            profile_data.get("external_url", ""),
            profile_data.get("followers_count", 0),
            profile_data.get("following_count", 0),
            profile_data.get("profile_pic_url", ""),
            1 if profile_data.get("is_private") else 0,
            json.dumps(profile_data.get("social_links", [])),
            datetime.now().isoformat(),
        ),
    )
    conn.commit()
    conn.close()


def get_cached_profile(username):
    conn = get_db()
    row = conn.execute(
        "SELECT * FROM profiles WHERE username = ?", (username,)
    ).fetchone()
    conn.close()
    if row and not _is_expired(row["scraped_at"]):
        return {
            "username": row["username"],
            "full_name": row["full_name"],
            "bio": row["bio"],
            "external_url": row["external_url"],
            "followers_count": row["followers_count"],
            "following_count": row["following_count"],
            "profile_pic_url": row["profile_pic_url"],
            "is_private": bool(row["is_private"]),
            "social_links": json.loads(row["social_links_json"] or "[]"),
            "scraped_at": row["scraped_at"],
        }
    return None


def cache_relationships(source_username, relationships, relationship_type):
    conn = get_db()
    now = datetime.now().isoformat()
    for target in relationships:
        conn.execute(
            """INSERT OR REPLACE INTO relationships
               (source_username, target_username, relationship_type, scraped_at)
               VALUES (?, ?, ?, ?)""",
            (source_username, target, relationship_type, now),
        )
    conn.commit()
    conn.close()


def get_cached_relationships(username, relationship_type):
    conn = get_db()
    rows = conn.execute(
        """SELECT target_username, scraped_at FROM relationships
           WHERE source_username = ? AND relationship_type = ?""",
        (username, relationship_type),
    ).fetchall()
    conn.close()
    if rows and not _is_expired(rows[0]["scraped_at"]):
        return [row["target_username"] for row in rows]
    return None
