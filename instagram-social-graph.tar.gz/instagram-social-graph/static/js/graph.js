let cy = null;
let graphData = null;

const PLATFORM_COLORS = {
    instagram: '#E1306C',
    twitter: '#1DA1F2',
    youtube: '#FF0000',
    tiktok: '#00F2EA',
    linkedin: '#0A66C2',
    facebook: '#1877F2',
    threads: '#FFFFFF',
    snapchat: '#FFFC00',
    pinterest: '#E60023',
    twitch: '#9146FF',
    spotify: '#1DB954',
    github: '#8B949E',
    linktree: '#43E55E',
    bio_link: '#888888',
};

const maxSlider = document.getElementById('max-connections');
const maxVal = document.getElementById('max-val');
maxSlider.addEventListener('input', () => {
    maxVal.textContent = maxSlider.value;
});

document.getElementById('username').addEventListener('keydown', (e) => {
    if (e.key === 'Enter') analyze();
});

function analyze() {
    const username = document.getElementById('username').value.trim().replace(/^@/, '');
    if (!username) return;

    const depth = parseInt(document.getElementById('depth').value);
    const maxConnections = parseInt(document.getElementById('max-connections').value);

    const btn = document.getElementById('analyze-btn');
    btn.disabled = true;
    btn.textContent = 'Analyzing...';

    document.getElementById('empty-state').style.display = 'none';
    document.getElementById('loading').style.display = 'block';
    document.getElementById('error-banner').style.display = 'none';
    document.getElementById('stats-bar').style.display = 'none';
    document.getElementById('legend').style.display = 'none';
    document.getElementById('export-bar').style.display = 'none';
    closeSidebar();

    fetch('/api/scrape', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username, depth, max_connections: maxConnections }),
    })
    .then(res => res.json())
    .then(data => {
        document.getElementById('loading').style.display = 'none';
        btn.disabled = false;
        btn.textContent = 'Analyze';

        if (data.error) {
            showError(data.error);
            return;
        }

        graphData = data;
        renderGraph(data);
        updateStats(data.stats);
        updateLegend(data.nodes);

        if (data.errors && data.errors.length > 0) {
            const msgs = data.errors.map(e => `${e.username}: ${e.error}`).join('; ');
            showError('Some profiles had issues: ' + msgs);
        }
    })
    .catch(err => {
        document.getElementById('loading').style.display = 'none';
        btn.disabled = false;
        btn.textContent = 'Analyze';
        showError('Request failed: ' + err.message);
    });
}

function showError(msg) {
    const banner = document.getElementById('error-banner');
    banner.textContent = msg;
    banner.style.display = 'block';
}

function renderGraph(data) {
    const elements = [];

    for (const node of data.nodes) {
        const color = node.color || PLATFORM_COLORS[node.type] || '#888';
        const size = node.type === 'instagram'
            ? Math.max(30, Math.min(80, 30 + Math.log10((node.followers_count || 1) + 1) * 10))
            : 25;

        elements.push({
            group: 'nodes',
            data: {
                id: node.id,
                label: node.label,
                type: node.type,
                color: color,
                size: size,
                ...node,
            },
        });
    }

    for (const edge of data.edges) {
        elements.push({
            group: 'edges',
            data: {
                id: edge.source + '->' + edge.target + ':' + edge.type,
                source: edge.source,
                target: edge.target,
                edgeType: edge.type,
            },
        });
    }

    if (cy) cy.destroy();

    cy = cytoscape({
        container: document.getElementById('cy'),
        elements: elements,
        style: [
            {
                selector: 'node',
                style: {
                    'background-color': 'data(color)',
                    'label': 'data(label)',
                    'color': '#e6edf3',
                    'font-size': '10px',
                    'text-valign': 'bottom',
                    'text-margin-y': 8,
                    'width': 'data(size)',
                    'height': 'data(size)',
                    'border-width': 2,
                    'border-color': '#30363d',
                    'text-outline-width': 2,
                    'text-outline-color': '#0d1117',
                },
            },
            {
                selector: 'node[type = "instagram"]',
                style: {
                    'border-width': 3,
                    'border-color': '#E1306C',
                },
            },
            {
                selector: 'edge',
                style: {
                    'width': 1.5,
                    'line-color': '#30363d',
                    'target-arrow-color': '#30363d',
                    'target-arrow-shape': 'triangle',
                    'curve-style': 'bezier',
                    'arrow-scale': 0.8,
                },
            },
            {
                selector: 'edge[edgeType = "linked_profile"]',
                style: {
                    'line-style': 'dashed',
                    'line-color': '#8b949e',
                    'target-arrow-shape': 'none',
                },
            },
            {
                selector: 'edge[edgeType = "follows"]',
                style: {
                    'line-color': '#E1306C',
                    'target-arrow-color': '#E1306C',
                    'opacity': 0.6,
                },
            },
            {
                selector: 'node:active',
                style: {
                    'overlay-opacity': 0.1,
                },
            },
            {
                selector: 'node:selected',
                style: {
                    'border-width': 4,
                    'border-color': '#ffffff',
                },
            },
        ],
        layout: {
            name: elements.length > 2 ? 'fcose' : 'grid',
            animate: true,
            animationDuration: 500,
            randomize: true,
            nodeSeparation: 100,
            idealEdgeLength: 150,
        },
        minZoom: 0.2,
        maxZoom: 5,
        wheelSensitivity: 0.3,
    });

    cy.on('tap', 'node', (evt) => {
        const node = evt.target.data();
        showNodeDetails(node);
    });

    cy.on('tap', (evt) => {
        if (evt.target === cy) {
            closeSidebar();
        }
    });

    document.getElementById('export-bar').style.display = 'flex';
}

function showNodeDetails(node) {
    const sidebar = document.getElementById('sidebar');
    const content = document.getElementById('sidebar-content');

    if (node.type === 'instagram') {
        const bio = escapeHtml(node.bio || 'No bio');
        const pic = node.pic
            ? `<img src="${escapeHtml(node.pic)}" alt="${escapeHtml(node.label)}" onerror="this.style.display='none'">`
            : '';

        content.innerHTML = `
            <div class="profile-card">
                ${pic}
                <h4>${escapeHtml(node.full_name || node.label)}</h4>
                <div class="username">@${escapeHtml(node.label)}</div>
                <div class="bio">${bio}</div>
                <div class="profile-stats">
                    <div class="ps">
                        <div class="ps-val">${formatNum(node.followers_count || 0)}</div>
                        <div class="ps-label">Followers</div>
                    </div>
                    <div class="ps">
                        <div class="ps-val">${formatNum(node.following_count || 0)}</div>
                        <div class="ps-label">Following</div>
                    </div>
                </div>
                ${node.error ? `<div class="error-banner">${escapeHtml(node.error)}</div>` : ''}
            </div>
        `;
    } else {
        const url = node.url || '#';
        content.innerHTML = `
            <div class="profile-card">
                <div class="platform-dot" style="background:${node.color || PLATFORM_COLORS[node.type] || '#888'}; width:40px; height:40px; margin:0 auto 12px; border-radius:50%;"></div>
                <h4>${escapeHtml(node.label)}</h4>
                <div class="username">${escapeHtml(node.type)}</div>
                <a href="${escapeHtml(url)}" target="_blank" rel="noopener" class="social-link-item" style="justify-content:center; margin-top:12px;">
                    Open Profile
                </a>
            </div>
        `;
    }

    sidebar.style.display = 'block';
}

function closeSidebar() {
    document.getElementById('sidebar').style.display = 'none';
}

function updateStats(stats) {
    document.getElementById('stat-nodes').textContent = stats.total_nodes;
    document.getElementById('stat-edges').textContent = stats.total_edges;
    document.getElementById('stat-profiles').textContent = stats.instagram_profiles;
    document.getElementById('stat-links').textContent = stats.social_links;
    document.getElementById('stats-bar').style.display = 'flex';
}

function updateLegend(nodes) {
    const types = new Set(nodes.map(n => n.type));
    const container = document.getElementById('legend-items');
    container.innerHTML = '';

    for (const type of types) {
        const color = PLATFORM_COLORS[type] || '#888';
        const label = type.charAt(0).toUpperCase() + type.slice(1).replace('_', ' ');
        const el = document.createElement('div');
        el.className = 'legend-item';
        el.innerHTML = `<span class="legend-dot" style="background:${color}"></span>${label}`;
        container.appendChild(el);
    }

    document.getElementById('legend').style.display = 'block';
}

function exportPng() {
    if (!cy) return;
    const png = cy.png({ output: 'blob', bg: '#0d1117', scale: 2 });
    const url = URL.createObjectURL(png);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'social-graph.png';
    a.click();
    URL.revokeObjectURL(url);
}

function exportJson() {
    if (!graphData) return;
    const blob = new Blob([JSON.stringify(graphData, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'social-graph.json';
    a.click();
    URL.revokeObjectURL(url);
}

function formatNum(n) {
    if (n >= 1000000) return (n / 1000000).toFixed(1) + 'M';
    if (n >= 1000) return (n / 1000).toFixed(1) + 'K';
    return n.toString();
}

function escapeHtml(str) {
    const div = document.createElement('div');
    div.textContent = str;
    return div.innerHTML;
}
