import re
from urllib.parse import urlparse

PLATFORM_PATTERNS = {
    "twitter": {
        "domains": ["twitter.com", "x.com"],
        "icon": "twitter",
        "color": "#000000",
        "label": "Twitter / X",
    },
    "youtube": {
        "domains": ["youtube.com", "youtu.be"],
        "icon": "youtube",
        "color": "#FF0000",
        "label": "YouTube",
    },
    "tiktok": {
        "domains": ["tiktok.com"],
        "icon": "tiktok",
        "color": "#00F2EA",
        "label": "TikTok",
    },
    "linkedin": {
        "domains": ["linkedin.com"],
        "icon": "linkedin",
        "color": "#0A66C2",
        "label": "LinkedIn",
    },
    "facebook": {
        "domains": ["facebook.com", "fb.com"],
        "icon": "facebook",
        "color": "#1877F2",
        "label": "Facebook",
    },
    "threads": {
        "domains": ["threads.net"],
        "icon": "threads",
        "color": "#000000",
        "label": "Threads",
    },
    "snapchat": {
        "domains": ["snapchat.com"],
        "icon": "snapchat",
        "color": "#FFFC00",
        "label": "Snapchat",
    },
    "pinterest": {
        "domains": ["pinterest.com"],
        "icon": "pinterest",
        "color": "#E60023",
        "label": "Pinterest",
    },
    "twitch": {
        "domains": ["twitch.tv"],
        "icon": "twitch",
        "color": "#9146FF",
        "label": "Twitch",
    },
    "spotify": {
        "domains": ["open.spotify.com", "spotify.com"],
        "icon": "spotify",
        "color": "#1DB954",
        "label": "Spotify",
    },
    "github": {
        "domains": ["github.com"],
        "icon": "github",
        "color": "#333333",
        "label": "GitHub",
    },
    "linktree": {
        "domains": ["linktr.ee"],
        "icon": "linktree",
        "color": "#43E55E",
        "label": "Linktree",
    },
    "bio_link": {
        "domains": ["bio.link", "beacons.ai", "lnk.bio", "campsite.bio"],
        "icon": "link",
        "color": "#888888",
        "label": "Bio Link",
    },
}

# All known social media domains for bare-domain matching
_ALL_DOMAINS = set()
for _info in PLATFORM_PATTERNS.values():
    for _d in _info["domains"]:
        _ALL_DOMAINS.add(re.escape(_d))
_BARE_DOMAIN_PATTERN = "|".join(sorted(_ALL_DOMAINS, key=len, reverse=True))

# Regex to find URLs in bio text (with protocol, www, or bare known domains)
URL_REGEX = re.compile(
    r'https?://[^\s<>"\')\]]+|(?:www\.)[^\s<>"\')\]]+'
    r"|(?:" + _BARE_DOMAIN_PATTERN + r')[^\s<>"\')\]]*',
    re.IGNORECASE,
)

# Regex to find @mentions that could be cross-platform
MENTION_REGEX = re.compile(r"@([A-Za-z0-9_.]+)")


def identify_platform(url):
    try:
        parsed = urlparse(url if "://" in url else f"https://{url}")
        domain = parsed.netloc.lower().lstrip("www.")
    except Exception:
        return None, None

    for platform, info in PLATFORM_PATTERNS.items():
        for pattern_domain in info["domains"]:
            if domain == pattern_domain or domain.endswith(f".{pattern_domain}"):
                username = _extract_username_from_path(parsed.path, platform)
                return platform, username
    return None, None


def _extract_username_from_path(path, platform):
    parts = [p for p in path.strip("/").split("/") if p]
    if not parts:
        return None
    if platform == "youtube" and parts[0].startswith("@"):
        return parts[0][1:]
    if platform == "youtube" and parts[0] in ("c", "channel", "user") and len(parts) > 1:
        return parts[1]
    if platform in ("twitter", "tiktok", "github", "threads"):
        username = parts[0]
        return username.lstrip("@")
    if platform == "linkedin" and parts[0] == "in" and len(parts) > 1:
        return parts[1]
    if platform == "facebook":
        return parts[0]
    return parts[0]


def extract_social_links(bio, external_url=None):
    links = []
    seen_platforms = set()

    all_urls = URL_REGEX.findall(bio or "")
    if external_url:
        all_urls.insert(0, external_url)

    for url in all_urls:
        url = url.rstrip(".,;:!?")
        platform, username = identify_platform(url)
        if platform and platform not in seen_platforms:
            seen_platforms.add(platform)
            info = PLATFORM_PATTERNS[platform]
            links.append({
                "platform": platform,
                "label": info["label"],
                "color": info["color"],
                "url": url if "://" in url else f"https://{url}",
                "username": username,
            })

    return links


def get_platform_color(platform):
    if platform in PLATFORM_PATTERNS:
        return PLATFORM_PATTERNS[platform]["color"]
    return "#888888"


def get_platform_label(platform):
    if platform in PLATFORM_PATTERNS:
        return PLATFORM_PATTERNS[platform]["label"]
    return platform.title()
