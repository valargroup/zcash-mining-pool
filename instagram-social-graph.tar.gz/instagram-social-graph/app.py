from flask import Flask, render_template, request, jsonify
from models import init_db, get_cached_profile
from scraper import build_graph, scrape_profile

app = Flask(__name__)

init_db()


@app.route("/")
def index():
    return render_template("index.html")


@app.route("/api/scrape", methods=["POST"])
def api_scrape():
    data = request.get_json()
    if not data or not data.get("username"):
        return jsonify({"error": "username is required"}), 400

    username = data["username"].strip().lstrip("@")
    depth = min(int(data.get("depth", 0)), 2)
    max_connections = min(int(data.get("max_connections", 50)), 200)

    graph = build_graph(username, depth=depth, max_connections=max_connections)
    return jsonify(graph)


@app.route("/api/profile/<username>")
def api_profile(username):
    profile = get_cached_profile(username)
    if profile:
        return jsonify(profile)
    # Try a fresh scrape
    profile = scrape_profile(username)
    return jsonify(profile)


if __name__ == "__main__":
    app.run(debug=True, host="0.0.0.0", port=5000)
